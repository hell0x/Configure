# _jsonschema_ module as a Package Control dependency

This is the [jsonschema](https://github.com/Julian/jsonschema) module bundled for use with Sublime Text's Package Control.

It's currently 3 commits ahead of [v2.6.0](https://github.com/Julian/jsonschema/releases/tag/v2.6.0).

Read about [dependencies](https://packagecontrol.io/docs/dependencies).


## License
The contents of the root folder in this repository are released under the __public domain__. The contents of the `all/` folder are under __their own bundled licenses__.
